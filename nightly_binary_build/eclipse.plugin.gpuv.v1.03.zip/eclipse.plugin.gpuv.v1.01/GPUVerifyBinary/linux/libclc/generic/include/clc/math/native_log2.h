#define native_log2 log2
