#define native_sin sin
