_CLC_DECL size_t get_global_size(uint dim);
