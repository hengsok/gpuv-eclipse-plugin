#define BODY <clc/math/mad.inc>
#include <clc/math/gentype.inc>
