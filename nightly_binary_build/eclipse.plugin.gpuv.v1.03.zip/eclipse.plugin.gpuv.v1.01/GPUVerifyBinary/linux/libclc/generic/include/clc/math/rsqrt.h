#define rsqrt(x) (1.f/sqrt(x))
