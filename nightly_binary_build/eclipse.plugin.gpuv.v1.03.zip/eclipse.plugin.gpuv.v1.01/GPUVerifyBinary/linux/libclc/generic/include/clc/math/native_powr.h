#define native_powr pow
