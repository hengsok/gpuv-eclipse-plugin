#define select(a, b, c) ((c) ? (b) : (a))
