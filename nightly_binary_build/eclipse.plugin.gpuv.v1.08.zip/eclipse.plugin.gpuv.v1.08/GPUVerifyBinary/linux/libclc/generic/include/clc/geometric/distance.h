#define BODY <clc/geometric/distance.inc>
#include <clc/geometric/floatn.inc>
