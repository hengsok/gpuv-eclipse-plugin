#define BODY <clc/integer/abs.inc>
#include <clc/integer/gentype.inc>
