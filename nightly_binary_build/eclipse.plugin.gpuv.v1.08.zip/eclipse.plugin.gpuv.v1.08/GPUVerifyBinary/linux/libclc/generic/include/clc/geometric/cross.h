_CLC_OVERLOAD _CLC_DECL float3 cross(float3 p0, float3 p1);
_CLC_OVERLOAD _CLC_DECL float4 cross(float4 p0, float4 p1);
