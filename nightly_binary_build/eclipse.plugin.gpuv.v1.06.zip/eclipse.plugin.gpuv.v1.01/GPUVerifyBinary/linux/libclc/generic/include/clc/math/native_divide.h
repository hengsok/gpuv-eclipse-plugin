#define native_divide(x, y) ((x) / (y))
