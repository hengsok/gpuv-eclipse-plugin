#define BODY <clc/geometric/dot.inc>
#include <clc/geometric/floatn.inc>
