#define BODY <clc/math/hypot.inc>
#include <clc/math/gentype.inc>
